<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductPackPackage extends Model
{
    //
}
